﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class ProduitsController : Controller
    {
        
        public ActionResult GetViewProducts()
        {
            FORMATIONEntities model;
            model = new FORMATIONEntities();
            List<Produit> p = model.PRODUITs.Select(o => new Produit() { ProduitID = o.ProduitID, Nom = o.Nom, Prix = o.Prix ,Description=o.Description}).ToList();

            ViewProductsViewModel vm;
            vm = new ViewProductsViewModel();
            vm.Produits = p;

            return View("GetViewProducts", vm);
        }
        public ActionResult ViewProducts()
        {

            return View();
        }
       


        private FORMATIONEntities FORMATIONEntities()
        {
            throw new NotImplementedException();
        }
        public ActionResult GetPartialViewProducts(int catID)
        {
             FORMATIONEntities model;
            model = new FORMATIONEntities();
            List<Produit> res;
            res = model.PRODUITs.Where(o => o.CategorieID == catID).Select(o => new Produit() { ProduitID = o.ProduitID, Nom = o.Nom, Prix = o.Prix }).ToList();


          

            ViewProductsViewModel vm;
            vm = new ViewProductsViewModel();
            vm.Produits = res;

            return PartialView("GetPartialViewProducts", vm);

        }





       public ActionResult Recherche()
        {
            return View("Recherche");
        }
        public ActionResult SearchProducts()
        {
            FORMATIONEntities model;
            model = new FORMATIONEntities();

            try
            {
                var produits = model.PRODUITs.ToList().Select(o => new
                {
                    ProduitID = o.ProduitID,
                    Nom = o.Nom,
                    Prix = o.Prix,
                    Categorie = o.CATEGORIE.Libelle
                });

                return Json(new { success = true, data = produits }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Probleme acces à la base" }, JsonRequestBehavior.AllowGet);
            }

        }

        public ActionResult Admin()
        {
            return View("Admin");
        }
    }
}

//PRODUIT x
// x= model.PRODUITS.Where(o => o.Prix>100).orderby(o=> o.Nom).Tolist();
// x= model.PRODUITS.Where(o => o.Prix>100).orderby(o=> o.Nom).FirstOrDefault(o=> o.CategerieID==1);
// pour lance dans la requette on peut faire Tolist() ou bien FirstOrDefault

// on peut faire  {model.PRODUITS.Where(o => o.Prix>100).Tolist().Where(o => o.Prix>100) } cette requette va envoyer seulement {model.PRODUITS.Where(o => o.Prix>100).Tolist()} et dans la parti client on va executer {.Where(o => o.Prix>100)}


