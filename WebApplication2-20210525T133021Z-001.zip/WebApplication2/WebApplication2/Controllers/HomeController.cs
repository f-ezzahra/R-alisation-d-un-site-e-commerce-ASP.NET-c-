﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Models;



namespace WebApplication2.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            
            return View();
        }     
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        [HttpGet]
        public ActionResult GetMyPage()
        {
            Client c1;
            c1 = new Client() { Nom = "aaa", Prenom = "Karim", Age = 23 };

            Client c2;
            c2 = new Client() { Nom = "bbb", Prenom = "Karim", Age = 12 };

            Client c3;
            c3 = new Client() { Nom = "ccc", Prenom = "Karim", Age = 35 };

            // =======================
            // C# : tableaux statiques
            // =======================

            //Client[] tab1;
            //tab1 = new Client[20];  // 20 cases une fois pour toute ---> tableau statique
            //tab1[0] = c1;
            //tab1[1] = c2;
            // tab1[2] contient null

            // ========================
            // C# : tableaux dynamiques
            // ========================

            List<Client> tab;
            tab = new List<Client>();
            tab.Add(c1);
            tab.Add(c2);
            tab.Add(c3);

            // tab2[0] represente le client c1

            // ==========================================
            // Donne moi tous les clients dont l'age > 26
            // select * from tab where age > 26 and ville = 'casa' and prenom = 'adil'
            // ==========================================

            // ANCIENNE METHODE :
            /*
            List<Client> res;
            res = new List<Client>();

            for(int i=0; i<tab.Count; i++)
            {
                if(tab[i].Age > 26)
                {
                    res.Add(tab[i]);
                }
            }
            */

            // NOUVELLE METHODE (.NET : c#/VB.net/C++) : LINQ : Language INtegrated Query
            // Requetes intégrées au langage
            //   SQL                  C#/VB


            List<Client> res;
            res = tab.Where(o => o.Age > 95).ToList();   // res va etre vide (res.Count vaut 0)


            // Requetes LINQ : where, firstordefault, orderby, min, max, count, groupby, select

            Client monclient;
            monclient = tab.FirstOrDefault(o => o.Age > 95);    // monclient est null
            
            if(monclient == null)
            {

            }
            else
            {
                string s = monclient.Nom;
            }

            return View("MyPage"); // html/head/body
        }

        [HttpPost]
        public ActionResult UpdateData(Client c)
        {

            return View("Index");
        }


        [HttpGet]
        public ActionResult GetClients()
        {
            // ==========================================================
            // 1. Requete sur la base pour recuperer la liste des clients (select * from CLIENTS where Age > 6 )
            // ==========================================================

            // List<Client> list;
            // list = dc.CLIENT.Where(o => o.Age > 6);   // Requete LINQ qui va me permettre d'interroger la BD

            // ===========================================
            // 2. On crée le model qui sera passé à la vue
            // ===========================================

            ClientsViewModel vm;
            vm = new ClientsViewModel();
            // vm.ListClients  = list;
            vm.Titre        = "COUCOU";
            vm.Count        = 456;

            // ====================
            // 3. J'appelle la page
            // ====================

            return View("Clients", vm);         // Clients.cshml
        }


        public ActionResult Paiement()
        {
            FORMATIONEntities model;
            model = new FORMATIONEntities();

            List<int> tab;
            List<Item> list;
            list = new List<Item>();

            tab = (List<int>)Session["PANIER"];

            List<Produit> res;

            PaiementViewModel vm;
            vm = new PaiementViewModel();

            res = model.PRODUITs.Select(o => new Produit() { ProduitID = o.ProduitID, Nom = o.Nom, Prix = o.Prix, Description = o.Description }).ToList();
            vm.Total = 0;
            foreach (Produit p in res)
            {
                vm.Total += (int)p.Prix;
            }
            vm.Items = list;
            return View("Paiement", vm);
        }


    }
}