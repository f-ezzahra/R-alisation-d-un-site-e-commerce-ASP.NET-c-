﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.Entity;
using System.Net;
using WebApplication2;
namespace WebApplication2.Controllers
{
    public class PRODUITSADMINController : Controller
    {
        private FORMATIONEntities db = new FORMATIONEntities();
     
        public ActionResult Index()
        {
            var pRODUITs = db.PRODUITs.Include(p => p.CATEGORIE).Include(p => p.FOURNISSEUR);
            return View(pRODUITs.ToList());
        }
        
        public ActionResult Create()
        {
            ViewBag.CategorieID = new SelectList(db.CATEGORIEs, "CategorieID", "libelle");
            ViewBag.FornisseurID = new SelectList(db.FOURNISSEURs, "FournisseurId", "Nom");
            return View();
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ProduitID,Nom,Description,Prix,FornisseurID,CategorieID")] PRODUIT pRODUIT)
        {
            if (ModelState.IsValid)
            {
                db.PRODUITs.Add(pRODUIT);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CategorieID = new SelectList(db.CATEGORIEs, "CategorieID", "libelle", pRODUIT.CategorieID);
            ViewBag.FornisseurID = new SelectList(db.FOURNISSEURs, "FournisseurId", "Nom", pRODUIT.FournisseurID);
            return View(pRODUIT);
        }

       
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PRODUIT pRODUIT = db.PRODUITs.Find(id);
            if (pRODUIT == null)
            {
                return HttpNotFound();
            }
            ViewBag.CategorieID = new SelectList(db.CATEGORIEs, "CategorieID", "libelle", pRODUIT.CategorieID);
            ViewBag.FornisseurID = new SelectList(db.FOURNISSEURs, "FournisseurId", "Nom", pRODUIT.FournisseurID);
            return View(pRODUIT);
        }

       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ProduitID,Nom,Description,Prix,FornisseurID,CategorieID")] PRODUIT pRODUIT)
        {
            if (ModelState.IsValid)
            {
                db.Entry(pRODUIT).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CategorieID = new SelectList(db.CATEGORIEs, "CategorieID", "libelle", pRODUIT.CategorieID);
            ViewBag.FornisseurID = new SelectList(db.FOURNISSEURs, "FournisseurId", "Nom", pRODUIT.FournisseurID);
            return View(pRODUIT);
        }
  
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PRODUIT pRODUIT = db.PRODUITs.Find(id);
            if (pRODUIT == null)
            {
                return HttpNotFound();
            }
            return View(pRODUIT);
        }

  
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            PRODUIT pRODUIT = db.PRODUITs.Find(id);
            db.PRODUITs.Remove(pRODUIT);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

    }
   
}