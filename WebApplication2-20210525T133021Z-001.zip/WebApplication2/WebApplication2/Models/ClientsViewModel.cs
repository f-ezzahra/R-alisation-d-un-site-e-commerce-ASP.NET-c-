﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    public class ClientsViewModel
    {
        public List<Client> ListClients { get; set; }
        public string Titre { get; set; }
        public int Count { get; set; }
    }
}