﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    public class Categorie
    {
        public int CategorieID { get; set; }
        public string Libelle { get; set; }

    }
}